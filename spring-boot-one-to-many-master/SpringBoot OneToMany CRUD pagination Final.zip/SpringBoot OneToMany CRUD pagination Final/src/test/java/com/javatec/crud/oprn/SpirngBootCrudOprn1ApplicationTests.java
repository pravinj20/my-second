package com.javatec.crud.oprn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpirngBootCrudOprn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
